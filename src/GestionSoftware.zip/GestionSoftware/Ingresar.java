package GestionSoftware;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class Ingresar extends JFrame {

    private static final String DB_URL  =
            "jdbc:mysql://localhost:3306/EmpresaLog" +
            "?useSSL=false" +
            "&allowPublicKeyRetrieval=true" +
            "&useUnicode=true&characterEncoding=UTF-8" +
            "&serverTimezone=America/Merida";
    private static final String DB_USER = "admin";
    private static final String DB_PASS = "12345ñ"; // si sigue fallando, usa ASCII puro

    // === Fuente por componente: Poppins 14/18 (con fallback) ===
    private static final Font POP18B = fontOrFallback("Poppins", Font.BOLD, 20);
    private static final Font POP16B = fontOrFallback("Poppins", Font.PLAIN, 14);
    private static final Font POP14B = fontOrFallback("Poppins", Font.BOLD, 14);
    private static final Font POP12B = fontOrFallback("Poppins", Font.BOLD, 12);

    // ========== CAMPOS ==========
    private final JTextField cpId        = tf("CARTA PORTE");
    private final JTextField cliente     = tf("CLIENTE");
    private final JTextField factura1    = tf("FACTURA (000000)");
    private final JTextField valor       = tf("VALOR ($Dolar)");
    private final JTextField fechaPago   = tf("FECHA DE PAGO");

    private final JTextField destino     = tf("DESTINO (Lugar y Pais)");
    private final JTextField referencia  = tf("REFERENCIA");
    private final JTextField remitente   = tf("REMITENTE");
    private final JTextField consignat   = tf("CONSIGNATORIO");
    private final JTextField factura2    = tf("FACTURA");

    private final JTextField operador    = tf("OPERADOR");
    private final JTextField placaCab    = tf("PLACA CABEZAL");
    private final JTextField placaFur    = tf("PLACA FURGON");
    private final JTextField valorFlete  = tf("VALOR FLETE");
    private final JTextField anticipo    = tf("ANTICIPO (Quetzal)");
    private final JTextField aCancel     = tf("A CANCELACION (Quetzal)");

    private final JTextField fechaPagado = tf("PAGADO (fecha)");
    private final JTextField fCarga      = tf("FECHA DE CARGA");
    private final JTextField fCruce      = tf("FECHA DE CRUCE");
    private final JTextField fSalTU      = tf("FECHA SAL. T.U.");
    private final JTextField fFDestino   = tf("FECHA F. DESTINO");
    private final JTextField fEnDestino  = tf("FECHA EN DESTINO");
    private final JTextField fDescarga   = tf("F. DESCARGA");
    private final JTextField fEDoctos    = tf("FECHA E. DE DOCTOS");

    private final JTextField custodio    = tf("CUSTODIO");
    private final JComboBox<String> pagado = new JComboBox<>(new String[]{"N/A","Sí","No","Pagado","Pendiente"});
    private final JTextArea  observaciones         = ta("OBSERVACIONES");

    // Carga y escala el logo desde recursos del classpath.
    // Coloca el archivo en: src/GestionSoftware/imagenes/LogoLeon.PNG
    private ImageIcon loadLogo(int heightPx) {
        java.net.URL url = Ingresar.class.getResource("/GestionSoftware/imagenes/LogoLeon.PNG");
        if (url == null) {
            System.err.println("⚠ No se encontró el recurso: /GestionSoftware/imagenes/LogoLeon.PNG");
            return null;
        }
        ImageIcon raw = new ImageIcon(url);
        int w = (int) Math.round((double) raw.getIconWidth() * heightPx / raw.getIconHeight());
        Image img = raw.getImage().getScaledInstance(w, heightPx, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }

    public Ingresar() {
        // ===== Ventana base =====
        setTitle("Nueva Carta de Porte - Administrador");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1400, 800);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(248,250,252)); // fondo claro
        setResizable(true);

        // ===== PANEL CABEZAL =====
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 20));
        header.setBackground(new Color(186, 185, 181));
        header.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(230,235,240)));
        JButton volver = new JButton("<");
        volver.setFocusPainted(false);
        volver.setBackground(new Color(33,150,243));
        volver.setForeground(Color.WHITE);
        volver.setBounds(0, 0, 50, 50);
        volver.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        volver.setFont(new Font("Poppins", Font.BOLD, 30));
        JLabel titulo = new JLabel("AGREGAR UN NUEVO REGISTRO");
        titulo.setFont(POP18B);
        titulo.setForeground(new Color(0,0,0));
        header.add(volver);
        header.add(titulo);
        add(header, BorderLayout.NORTH);

        // ACCION DE REGRESAR CON LA TECLA ESC
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke("ESCAPE"), "ESC");
        getRootPane().getActionMap().put("ESC", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { volver.doClick(); }
        });
        volver.addActionListener(e -> {
            new Registros().setVisible(true);
            dispose();
        });
        addHover(volver, new Color(225, 90, 90));

        // ===== PESTAÑAS =====
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(POP18B);
        tabs.setBackground(Color.white);

        // Wrappers para la pestaña 3 (helpers reutilizables)
        JComponent comboPagado = wrapCombo("Pagado", pagado);
        JComponent obsWrap     = wrapTextArea("OBSERVACIONES", observaciones);

        tabs.addTab("1. Datos Principales", buildGrid(
                cpId, cliente, factura1, valor,
                withDatePicker(fechaPago),
                destino, referencia, remitente, consignat, factura2
        ));
        tabs.addTab("2. Participantes & Unidades", buildGrid(
                operador,
                placaCab, placaFur, valorFlete, anticipo, aCancel,
                withDatePicker(fechaPagado)
        ));
        tabs.addTab("3. Fechas del Viaje", buildGrid(
                withDatePicker(fCarga),
                withDatePicker(fCruce),
                withDatePicker(fSalTU),
                withDatePicker(fFDestino),
                withDatePicker(fEnDestino),
                withDatePicker(fDescarga),
                withDatePicker(fEDoctos),
                // — elementos migrados de "Otros" —
                custodio,      // JTextField normal
                comboPagado,   // JComboBox envuelto con título
                obsWrap        // JTextArea envuelta con ScrollPane y título
        ));
        add(tabs, BorderLayout.CENTER);

        // Recalcular A_CANCELACION en tiempo real
        DocumentListener dl = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { recalc(); }
            public void removeUpdate(DocumentEvent e) { recalc(); }
            public void changedUpdate(DocumentEvent e) { recalc(); }
        };
        valorFlete.getDocument().addDocumentListener(dl);
        anticipo.getDocument().addDocumentListener(dl);
        aCancel.setEditable(false);

        // ===== Pie de Pagina =====
        JPanel footer = new JPanel(new BorderLayout(10, 10));
        footer.setBackground(new Color(52, 57, 63));

        // IZQUIERDA: Logo
        JLabel logoLeft = new JLabel();
        logoLeft.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        logoLeft.setOpaque(false);
        ImageIcon logoIcon = loadLogo(96);
        if (logoIcon != null) logoLeft.setIcon(logoIcon);
        footer.add(logoLeft, BorderLayout.WEST);

        // DERECHA: Botón Registrar (GRANDE)
        JPanel rightBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 32, 24));
        rightBtns.setOpaque(false);

        JButton registrar = new JButton("Registrar");
        registrar.setFocusPainted(false);
        registrar.setBackground(new Color(33,150,243));
        registrar.setForeground(Color.WHITE);
        registrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registrar.setFont(fontOrFallback("Poppins", Font.BOLD, 18));
        registrar.setBorder(BorderFactory.createEmptyBorder(14, 32, 14, 32)); // padding interno
        registrar.setPreferredSize(new Dimension(180, 50));
        registrar.setMinimumSize(new Dimension(240, 70));

        addHover(registrar, new Color(0, 194, 250));
        registrar.addActionListener(e -> guardar());

        rightBtns.add(registrar);
        footer.add(rightBtns, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        // Fuente combo
        pagado.setFont(POP14B);
    }

    // ================== UI Helpers (con Poppins 14 Bold) ==================
    private static JTextField tf(String title) {
        JTextField t = new JTextField();
        t.setBorder(titled(title));
        t.setOpaque(true);
        t.setBackground(Color.white);
        t.setForeground(Color.BLACK);
        t.setFont(new Font("Poppins", Font.BOLD, 20));
        t.setColumns(18);
        return t;
    }

    // CAMPO DE TEXTO DE OBSERVACIONES
    private static JTextArea ta(String title) {
        JTextArea t = new JTextArea(5, 50);
        t.setBorder(titled(title));
        t.setFont(new Font("Poppins", Font.BOLD, 20));
        t.setForeground(Color.BLACK);
        t.setLineWrap(true);
        t.setWrapStyleWord(true);
        return t;
    }

    private static TitledBorder titled(String title) {
        TitledBorder tb = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(255,255,255), 10), title);
        tb.setTitleFont(POP16B);
        tb.setTitleColor(Color.BLACK);
        return tb;
    }

    private static void addHover(JButton b, Color hover) {
        Color base = b.getBackground();
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(hover); }
            @Override public void mouseExited (java.awt.event.MouseEvent e) { b.setBackground(base);  }
        });
    }

    // CONFIGURACION PARA CADA COMPONENTE DE LOS TABS
    private JPanel buildGrid(JComponent... comps) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(true);
        p.setBackground(new Color(211,211,211));
        p.setBorder(BorderFactory.createEmptyBorder(8,8,80,50));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8,8,8,8);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.gridx = 0; c.gridy = 0;
        for (JComponent comp : comps) {
            comp.setFont(new Font("Poppins", Font.BOLD, 20));
            p.add(comp, c);
            if (c.gridx == 0) c.gridx = 1;
            else { c.gridx = 0; c.gridy++; }
        }
        return p;
    }

    // ================== Lógica ==================
    private void recalc() {
        double vf = parseMoney(valorFlete.getText());
        double an = parseMoney(anticipo.getText());
        if (Double.isNaN(vf)) vf = 0;
        if (Double.isNaN(an)) an = 0;
        aCancel.setText(String.format("%.2f", vf - an));
    }

    private static double parseMoney(String s) {
        if (s == null) return Double.NaN;
        s = s.trim().replace("$","").replace("Q","").replace(",","");
        if (s.isEmpty()) return Double.NaN;
        try { return Double.parseDouble(s); } catch (NumberFormatException e) { return Double.NaN; }
    }

    private static boolean empty(JTextField t) { return t.getText().trim().isEmpty(); }

    private static Double toNullableDouble(String s) {
        double d = parseMoney(s);
        return Double.isNaN(d) ? null : d;
    }

    private static void setNullableDouble(PreparedStatement ps, int idx, Double val) throws SQLException {
        if (val == null) ps.setNull(idx, java.sql.Types.DECIMAL);
        else ps.setDouble(idx, val);
    }

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    private void guardar() {
        if (empty(cpId) || empty(cliente)) {
            JOptionPane.showMessageDialog(this, "Carta de Porte y Cliente son obligatorios.");
            return;
        }
        if (cpId.getText().trim().length() > 10) {
            JOptionPane.showMessageDialog(this, "CARTA PORTE debe tener máximo 10 caracteres (VARCHAR(10)).");
            return;
        }

        Double v  = toNullableDouble(valor.getText());
        Double vf = toNullableDouble(valorFlete.getText());
        Double an = toNullableDouble(anticipo.getText());
        Double ac = toNullableDouble(aCancel.getText());

        String sql = "INSERT INTO Carta_Porte (" +
                "Carta_Porte_id, Cliente, FACTURA, VALOR, FECHA_DE_PAGO, DESTINO, REFERENCIA, " +
                "REMITENTE, CONSIGNATORIO, FACTURA2, OPERADOR, PLACA_CABEZAL, PLACA_DEL_FURGON, " +
                "VALOR_FLETE, ANTICIPO, A_CANCELACION, FECHA_DE_PAGADO, F_DE_CARGA, F_DE_CRUCE, " +
                "F_SAL_T_U, F_F_DESTINO, F_EN_DESTINO, F_DESCARGA, F_E_DE_DOCTOS, CUSTODIO, " +
                "PAGADO, OBSERVACIONES) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        try (Connection cn = getConnection()) {

            // Validar duplicado de PK
            try (PreparedStatement chk = cn.prepareStatement(
                    "SELECT 1 FROM Carta_Porte WHERE Carta_Porte_id = ?")) {
                chk.setString(1, cpId.getText().trim());
                try (ResultSet r = chk.executeQuery()) {
                    if (r.next()) {
                        JOptionPane.showMessageDialog(this,
                                "Ya existe una Carta de Porte con ese ID.",
                                "Duplicado", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                }
            }

            try (PreparedStatement ps = cn.prepareStatement(sql)) {
                int i = 1;
                ps.setString(i++, cpId.getText().trim());
                ps.setString(i++, cliente.getText().trim());
                ps.setString(i++, factura1.getText().trim());
                setNullableDouble(ps, i++, v);
                ps.setString(i++, fechaPago.getText().trim());
                ps.setString(i++, destino.getText().trim());
                ps.setString(i++, referencia.getText().trim());
                ps.setString(i++, remitente.getText().trim());
                ps.setString(i++, consignat.getText().trim());
                ps.setString(i++, factura2.getText().trim());
                ps.setString(i++, operador.getText().trim());
                ps.setString(i++, placaCab.getText().trim());
                ps.setString(i++, placaFur.getText().trim());
                setNullableDouble(ps, i++, vf);
                setNullableDouble(ps, i++, an);
                setNullableDouble(ps, i++, ac);
                ps.setString(i++, fechaPagado.getText().trim());
                ps.setString(i++, fCarga.getText().trim());
                ps.setString(i++, fCruce.getText().trim());
                ps.setString(i++, fSalTU.getText().trim());
                ps.setString(i++, fFDestino.getText().trim());
                ps.setString(i++, fEnDestino.getText().trim());
                ps.setString(i++, fDescarga.getText().trim());
                ps.setString(i++, fEDoctos.getText().trim());
                ps.setString(i++, custodio.getText().trim());
                ps.setString(i++, (String) pagado.getSelectedItem());
                ps.setString(i++, observaciones.getText().trim());

                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Carta de Porte registrada correctamente.");
                limpiar();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void limpiar() {
        JTextField[] all = {
                cpId, cliente, factura1, valor, fechaPago, destino, referencia,
                remitente, consignat, factura2, operador, placaCab, placaFur,
                valorFlete, anticipo, aCancel, fechaPagado, fCarga, fCruce,
                fSalTU, fFDestino, fEnDestino, fDescarga, fEDoctos, custodio
        };
        for (JTextField t : all) t.setText("");
        pagado.setSelectedIndex(0);
        observaciones.setText("");
    }

    // ====== Utilidad: probar conexión rápidamente ======
    private static void probarConexion() {
        try (Connection cn = getConnection()) {
            DatabaseMetaData md = cn.getMetaData();
            System.out.println(" Conectado a: " + md.getDatabaseProductName() + " " + md.getDatabaseProductVersion());
        } catch (SQLException e) {
            System.err.println(" Falló la conexión: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ======================= Calendario UI =======================
    private static final String[] MESES_ES = {
            "enero","febrero","marzo","abril","mayo","junio",
            "julio","agosto","septiembre","octubre","noviembre","diciembre"
    };

    /** Envuelve un JTextField con un botón 📅 que abre el selector de fecha. */
    private JComponent withDatePicker(JTextField field) {
        Border original = field.getBorder();
        field.setBorder(BorderFactory.createEmptyBorder(6,8,6,8));

        JPanel wrapper = new JPanel(new BorderLayout(6,0));
        wrapper.setOpaque(true);
        wrapper.setBackground(Color.white);
        if (original != null) wrapper.setBorder(original);
        wrapper.add(field, BorderLayout.CENTER);

        JButton btn = new JButton("📅");
        btn.setMargin(new Insets(2,8,2,8));
        btn.setFocusPainted(false);
        btn.setBackground(Color.CYAN);
        btn.setToolTipText("Seleccionar fecha");
        btn.setFont(POP14B);
        btn.addActionListener(e -> showFechaDialog(field));
        wrapper.add(btn, BorderLayout.EAST);

        return wrapper;
    }

    /** Helper: envuelve un JComboBox con borde titulado consistente. */
    private JPanel wrapCombo(String title, JComboBox<?> combo) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(true);
        p.setBackground(Color.white);
        p.setBorder(titled(title));
        combo.setFont(new Font("Poppins", Font.BOLD, 17));
        p.add(combo, BorderLayout.CENTER);
        return p;
    }

    /** Helper: envuelve un JTextArea con ScrollPane y título en el contenedor externo. */
    private JComponent wrapTextArea(String title, JTextArea area) {
        // quitamos borde al área para evitar doble título
        area.setBorder(BorderFactory.createEmptyBorder(6,8,6,8));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);

        JScrollPane sp = new JScrollPane(area);
        sp.setBorder(BorderFactory.createEmptyBorder());

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(true);
        wrapper.setBackground(Color.white);
        wrapper.setBorder(titled(title));
        wrapper.add(sp, BorderLayout.CENTER);
        return wrapper;
    }

    /** Abre el diálogo para seleccionar fecha y escribirla como '6 de septiembre de 2025'. */
    private void showFechaDialog(JTextField target) {
        LocalDate pre = parseFechaFlexible(target.getText());
        if (pre == null) pre = LocalDate.now();
        new FechaDialog(this, target, pre).setVisible(true);
    }

    /** Convierte LocalDate -> '6 de septiembre de 2025' */
    private static String formatFechaLarga(LocalDate d) {
        String mes = MESES_ES[d.getMonthValue()-1];
        return d.getDayOfMonth() + " de " + mes + " de " + d.getYear();
    }

    /** Intenta leer '6 de septiembre de 2025', '06/09/2025' o '2025-09-06'. */
    private static LocalDate parseFechaFlexible(String s) {
        if (s == null) return null;
        String x = s.trim().toLowerCase();
        if (x.isEmpty()) return null;
        try {
            if (x.matches("\\d{4}-\\d{2}-\\d{2}")) return LocalDate.parse(x);
            if (x.matches("\\d{1,2}/\\d{1,2}/\\d{4}")) {
                String[] p = x.split("/");
                int d = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]), y = Integer.parseInt(p[2]);
                return LocalDate.of(y, m, d);
            }
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(\\d{1,2})\\s+de\\s+([a-záéíóúñ]+)\\s+de\\s+(\\d{4})")
                    .matcher(x);
            if (m.find()) {
                int d = Integer.parseInt(m.group(1));
                String mesTxt = m.group(2);
                int y = Integer.parseInt(m.group(3));
                int mesNum = 0;
                for (int i=0; i<MESES_ES.length; i++) {
                    if (MESES_ES[i].equals(mesTxt)) { mesNum = i+1; break; }
                }
                if (mesNum>0) return LocalDate.of(y, mesNum, d);
            }
        } catch (Exception ignore) {}
        return null;
    }

    private static int daysInMonth(int year, int month1to12) {
        return java.time.Month.of(month1to12).length(java.time.Year.isLeap(year));
    }

    /** Diálogo modal para escoger fecha (día/mes/año) con vista previa. */
    private class FechaDialog extends JDialog {
        private final JTextField target;
        private final JComboBox<Integer> cbDia;
        private final JComboBox<String>  cbMes;
        private final JComboBox<Integer> cbAnio;
        private final JLabel preview;

        FechaDialog(Frame owner, JTextField target, LocalDate initial) {
            super(owner, "Seleccionar fecha", true);
            this.target = target;

            setSize(420, 240);
            setLocationRelativeTo(owner);
            setLayout(new BorderLayout(10,10));
            ((JComponent)getContentPane()).setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
            getContentPane().setBackground(Color.white);

            // PANEL CENTRAL
            JPanel center = new JPanel(new GridBagLayout());
            center.setOpaque(true);
            center.setBackground(Color.white);
            GridBagConstraints c = new GridBagConstraints();
            c.insets = new Insets(6,6,6,6);
            c.fill = GridBagConstraints.HORIZONTAL;

            // Año: (hoy-70) .. (hoy+10)
            int yNow = LocalDate.now().getYear();
            List<Integer> años = new ArrayList<>();
            for (int y = yNow-70; y <= yNow+10; y++) años.add(y);

            cbDia  = new JComboBox<>();
            cbMes  = new JComboBox<>(MESES_ES);
            cbAnio = new JComboBox<>(años.toArray(new Integer[0]));
            cbDia.setFont(POP14B);
            cbMes.setFont(POP14B);
            cbAnio.setFont(POP14B);

            cbMes.setSelectedIndex(initial.getMonthValue()-1);
            cbAnio.setSelectedItem(initial.getYear());
            refillDias();
            cbDia.setSelectedItem(initial.getDayOfMonth());

            preview = new JLabel(formatFechaLarga(getDate()));
            preview.setFont(POP14B);

            ActionListener upd = e -> {
                refillDias();
                preview.setText(formatFechaLarga(getDate()));
            };
            cbMes.addActionListener(upd);
            cbAnio.addActionListener(upd);
            cbDia.addActionListener(e -> preview.setText(formatFechaLarga(getDate())));

            JLabel lDia = new JLabel("Día:");     lDia.setFont(POP14B);
            JLabel lMes = new JLabel("Mes:");     lMes.setFont(POP14B);
            JLabel lAnio= new JLabel("Año:");     lAnio.setFont(POP14B);

            c.gridx=0; c.gridy=0; center.add(lDia, c);
            c.gridx=1; c.gridy=0; center.add(cbDia, c);
            c.gridx=0; c.gridy=1; center.add(lMes, c);
            c.gridx=1; c.gridy=1; center.add(cbMes, c);
            c.gridx=0; c.gridy=2; center.add(lAnio, c);
            c.gridx=1; c.gridy=2; center.add(cbAnio, c);

            JPanel pv = new JPanel(new FlowLayout(FlowLayout.CENTER));
            pv.setOpaque(true);
            pv.setBackground(Color.white);
            pv.add(preview);

            JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
            south.setOpaque(true);
            south.setBackground(Color.white);

            JButton btnHoy = new JButton("Hoy");
            btnHoy.setFont(new Font("Poppins", Font.BOLD, 14));
            btnHoy.setFocusPainted(false);
            btnHoy.setBackground(new Color(33,150,243));
            btnHoy.setForeground(Color.BLACK);
            btnHoy.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 20));
            btnHoy.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            JButton btnAsignar = new JButton("Asignar");
            JButton btnCancelar = new JButton("Cancelar");

            // south.add(btnHoy); // si lo quieres visible, descomenta
            south.add(btnCancelar);
            south.add(btnAsignar);

            btnHoy.addActionListener(e -> {
                LocalDate now = LocalDate.now();
                cbMes.setSelectedIndex(now.getMonthValue()-1);
                cbAnio.setSelectedItem(now.getYear());
                refillDias();
                cbDia.setSelectedItem(now.getDayOfMonth());
                preview.setText(formatFechaLarga(getDate()));
            });

            btnCancelar.addActionListener(e -> dispose());
            btnAsignar.addActionListener(e -> {
                target.setText(formatFechaLarga(getDate()));
                dispose();
            });

            getRootPane().setDefaultButton(btnAsignar);
            getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                    .put(KeyStroke.getKeyStroke("ESCAPE"), "ESC");
            getRootPane().getActionMap().put("ESC", new AbstractAction() {
                @Override public void actionPerformed(ActionEvent e) { dispose(); }
            });

            add(center, BorderLayout.WEST);
            add(pv, BorderLayout.CENTER);
            add(south, BorderLayout.SOUTH);
        }

        private void refillDias() {
            int y = (Integer) cbAnio.getSelectedItem();
            int m = cbMes.getSelectedIndex()+1;
            int max = daysInMonth(y, m);
            Integer sel = (Integer) cbDia.getSelectedItem();
            cbDia.removeAllItems();
            for (int d=1; d<=max; d++) cbDia.addItem(d);
            if (sel != null && sel <= max) cbDia.setSelectedItem(sel);
        }

        private LocalDate getDate() {
            int d = (Integer) cbDia.getSelectedItem();
            int m = cbMes.getSelectedIndex()+1;
            int y = (Integer) cbAnio.getSelectedItem();
            return LocalDate.of(y, m, d);
        }
    }

    // ======= Utilidad: construir Poppins con fallback simple por componente =======
    private static Font fontOrFallback(String name, int style, int size) {
        Font f = new Font(name, style, size);
        // Si Poppins no está disponible, Java devolverá otra familia; forzamos fallback a SansSerif.
        if (!name.equalsIgnoreCase(f.getFamily())) {
            f = new Font(Font.SANS_SERIF, style, size);
        }
        return f;
    }

    public static void main(String[] args) {
        // Nimbus (opcional)
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("System".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            Ingresar clase = new Ingresar();
            clase.setVisible(true);
        });
    }
}
