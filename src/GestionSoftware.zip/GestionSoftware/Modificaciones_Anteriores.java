package GestionSoftware;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.InputStream;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Vector;

import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class Modificaciones_Anteriores extends JFrame {

    // ==========================
    // UI
    // ==========================
    private JTable tabla;
    private DefaultTableModel modelo;
    private TableRowSorter<DefaultTableModel> sorter;
    private JComboBox<String> cbRango;
    private JButton btnRefrescar;
    private JButton btnDetalle;
    private JButton B1; // botón regreso
    private JLabel lblTitulo;
    private JScrollPane scrollPane;

    // Logo
    private JLabel logoLabel;
    private static final String LOGOImagen = "/GestionSoftware/imagenes/LogoLeon.PNG";

    // Layout (coordenadas fijas en Y; sólo ajustaremos el ANCHO)
    private static final int MARGIN_X   = 20;
    private static final int SCROLL_X   = MARGIN_X;
    private static final int SCROLL_Y   = 120;
    private static final int SCROLL_H   = 520; // NO se toca la altura

    // ==========================
    // DB
    // ==========================
    private static final String DB_URL  = "jdbc:mysql://localhost:3306/EmpresaLog?useSSL=false&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=America/Merida";
    private static final String DB_USER = "admin";
    private static final String DB_PASS = "12345ñ";

    // Auditoría REAL
    private static final String AUDIT_TABLE = "AUDITORIA";

    // ==========================
    // Constructor
    // ==========================
    public Modificaciones_Anteriores() {
        setTitle("Modificaciones anteriores");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1400, 800);
        setResizable(true);
        setLocationRelativeTo(null);
        getContentPane().setLayout(null);
        getContentPane().setBackground(new Color(240, 242, 245));

        // Icono de la ventana
        ImageIcon appIcon = scaledIcon(LOGOImagen, 32, 32);
        if (appIcon != null) setIconImage(appIcon.getImage());

        // Título
        lblTitulo = new JLabel("HISTORIAL DE MODIFICACIONES", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Poppins", Font.BOLD, 24));
        lblTitulo.setBounds(400, 15, 540, 40);
        getContentPane().add(lblTitulo);

        // Botón regreso (B1)
        B1 = new JButton("<");
        B1.setBackground(Color.WHITE);
        B1.setBounds(10, 10, 50, 50);
        B1.setFocusPainted(false);
        B1.setToolTipText("Regresar");
        getContentPane().add(B1);

        B1.addActionListener(e -> {
            try {
                Registros reg = new Registros();
                reg.setVisible(true);
            } catch (Throwable ignore) {}
            dispose();
        });
        B1.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { B1.setBackground(Color.RED); }
            @Override public void mouseExited (MouseEvent e) { B1.setBackground(Color.WHITE); }
        });

        // ESC -> volver
        JRootPane raizEsc = getRootPane();
        KeyStroke TeclaSalir = KeyStroke.getKeyStroke("ESCAPE");
        raizEsc.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(TeclaSalir, "ESCAPE");
        raizEsc.getActionMap().put("ESCAPE", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { B1.doClick(); }
        });

        // Logo (arriba)
        logoLabel = new JLabel();
        logoLabel.setOpaque(false);
        getContentPane().add(logoLabel);
        setLogoBounds(1000, 30, 100, 90);

        // Controles de rango
        JLabel lblRango = new JLabel("Rango:");
        lblRango.setFont(new Font("Poppins", Font.BOLD, 14));
        lblRango.setBounds(60, 75, 60, 28);
        getContentPane().add(lblRango);

        cbRango = new JComboBox<>(new String[] { "Esta semana", "Este mes", "Este año", "Todo" });
        cbRango.setBounds(120, 75, 180, 32);
        cbRango.setFocusable(false);
        getContentPane().add(cbRango);

        btnRefrescar = new JButton("Refrescar");
        btnRefrescar.setFont(new Font("Poppins", Font.BOLD, 14));
        btnRefrescar.setBounds(315, 75, 120, 32);
        getContentPane().add(btnRefrescar);

        btnDetalle = new JButton("Detalles");
        btnDetalle.setFont(new Font("Poppins", Font.BOLD, 14));
        btnDetalle.setBounds(450, 75, 120, 32);
        getContentPane().add(btnDetalle);

        // Modelo de la tabla
        modelo = new DefaultTableModel() {
            @Override public boolean isCellEditable(int row, int col) { return false; }
            @Override public Class<?> getColumnClass(int columnIndex) {
                switch (columnIndex) {
                    case 0:  return String.class;               // fecha bonita
                    case 1:  return String.class;               // acción
                    case 2:  return String.class;               // descripción
                    case 3:  return Integer.class;              // id
                    case 7:  return java.math.BigDecimal.class; // VALOR
                    default: return String.class;
                }
            }
        };
        
        
        String[] cols = {
            "Fecha y hora", "Movimiento", "Descripción", "Carta_Porte_id",
            "Cliente"
        };
        for (String c : cols) modelo.addColumn(c);

        // Tabla
        tabla = new JTable(modelo);
        tabla.setRowHeight(24);
        tabla.setFont(new Font("Arial", Font.BOLD, 12));
        tabla.setBackground(Color.WHITE);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        JTableHeader header = tabla.getTableHeader();
        header.setFont(new Font("Poppins", Font.BOLD, 14));
        header.setBackground(new Color(135, 206, 235));
        header.setReorderingAllowed(true);
        header.setResizingAllowed(true);

        sorter = new TableRowSorter<>(modelo);
        tabla.setRowSorter(sorter);

        // ScrollPane (ajustamos SOLO el ancho)
        scrollPane = new JScrollPane(tabla);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.getHorizontalScrollBar().setUnitIncrement(16);
        int anchoInicial = getContentPane().getWidth() - (MARGIN_X * 2);
        scrollPane.setBounds(SCROLL_X, SCROLL_Y, Math.max(200, anchoInicial), SCROLL_H);
        getContentPane().add(scrollPane);

        // SHIFT + rueda => scroll horizontal
        tabla.addMouseWheelListener(e -> {
            if (e.isShiftDown()) {
                JScrollBar h = scrollPane.getHorizontalScrollBar();
                int amount = e.getUnitsToScroll() * h.getUnitIncrement();
                h.setValue(h.getValue() + amount);
                e.consume();
            }
        });

        // Renderers/estilo
        configurarAnchosColumnas();
        aplicarRendererNumericos();
        aplicarZebra();

        // Eventos
        cbRango.addActionListener(e -> { cargarDatos(); ajustarSoloAncho(); });
        btnRefrescar.addActionListener(e -> { cargarDatos(); ajustarSoloAncho(); });
        btnDetalle.addActionListener(e -> verDetalleSeleccionado());

        // Ajuste SOLO de ANCHO en resize
        addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) { ajustarSoloAncho(); }
        });

        // Auditoría (DDL defensivo — opcional si ya la creaste por SQL)
        asegurarTablaAuditoria();

        // Carga
        cargarDatos();
        ajustarSoloAncho();
    }

    // ==========================
    // Ajuste ANCHO
    // ==========================
    private void ajustarSoloAncho() {
        int spW = Math.max(200, getContentPane().getWidth() - (MARGIN_X * 2));
        scrollPane.setBounds(SCROLL_X, SCROLL_Y, spW, SCROLL_H);

        SwingUtilities.invokeLater(() -> {
            TableColumnModel tcm = tabla.getColumnModel();
            if (tcm.getColumnCount() == 0) return;

            int totalPref = 0;
            for (int i = 0; i < tcm.getColumnCount(); i++) totalPref += tcm.getColumn(i).getPreferredWidth();

            int viewportW = scrollPane.getViewport().getWidth();
            if (viewportW <= 0) return;

            int extra = viewportW - totalPref;
            if (extra > 0) {
                int last = tcm.getColumnCount() - 1;
                TableColumn lastCol = tcm.getColumn(last);
                lastCol.setPreferredWidth(lastCol.getPreferredWidth() + extra);
                lastCol.setMinWidth(70);
                tabla.revalidate();
                tabla.repaint();
            }
        });
    }

    // ==========================
    // Logo
    // ==========================
    private void setLogoBounds(int x, int y, int w, int h) {
        if (logoLabel == null) return;
        logoLabel.setBounds(x, y, w, h);
        ImageIcon imagenLogo = scaledIcon(LOGOImagen, w, h);
        if (imagenLogo != null) logoLabel.setIcon(imagenLogo);
        logoLabel.revalidate();
        logoLabel.repaint();
    }

    // ==========================
    // Carga de datos
    // ==========================
    private void cargarDatos() {
        modelo.setRowCount(0);

        String filtro = (String) cbRango.getSelectedItem();
        Timestamp desde = calcularInicioPorRango(filtro);

        StringBuilder sql = new StringBuilder(
            "SELECT a.modificado_en, a.accion, a.descripcion, " +
            "       cp.Carta_Porte_id, cp.Cliente, cp.FACTURA, cp.FECHA_FACTURA, " +
            "       cp.VALOR, cp.DESTINO, cp.Operador, cp.PLACA_CABEZAL, cp.PLACA_DEL_FURGON, " +
            "       cp.PAGADO, cp.OBSERVACIONES " +
            "FROM " + AUDIT_TABLE + " a " +
            "LEFT JOIN Carta_Porte cp ON cp.Carta_Porte_id = a.Carta_Porte_id "
        );
        if (desde != null) sql.append("WHERE a.modificado_en >= ? ");
        sql.append("ORDER BY a.modificado_en DESC");

        try (Connection c = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql.toString())) {

            if (desde != null) ps.setTimestamp(1, desde);

            try (ResultSet rs = ps.executeQuery()) {
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d 'de' MMMM 'del' yyyy HH:mm")
                        .withLocale(new java.util.Locale("es","MX"));

                while (rs.next()) {
                    Timestamp ts = rs.getTimestamp(1);
                    String modNice = ts == null ? "" : fmt.format(ts.toLocalDateTime());

                    Vector<Object> row = new Vector<>();
                    row.add(modNice);                 // 0 fecha
                    row.add(nz(rs.getString(2)));     // 1 acción
                    row.add(nz(rs.getString(3)));     // 2 descripción
                    row.add(rs.getObject(4));         // 3 id
                    row.add(nz(rs.getString(5)));     // 4 Cliente
                    row.add(nz(rs.getString(6)));     // 5 FACTURA
                    row.add(nz(rs.getString(7)));     // 6 FECHA_FACTURA
                    row.add(rs.getBigDecimal(8));     // 7 VALOR
                    row.add(nz(rs.getString(9)));     // 8 DESTINO
                    row.add(nz(rs.getString(10)));    // 9 OPERADOR
                    row.add(nz(rs.getString(11)));    // 10 PLACA_CABEZAL
                    row.add(nz(rs.getString(12)));    // 11 PLACA_DEL_FURGON
                    row.add(nz(rs.getString(13)));    // 12 PAGADO
                    row.add(nz(rs.getString(14)));    // 13 OBSERVACIONES
                    modelo.addRow(row);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "No pude cargar el historial. " + AUDIT_TABLE + "'.\n" + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String nz(String s) { return (s == null) ? "" : s; }

    // rango
    private Timestamp calcularInicioPorRango(String rango) {
        if (rango == null) return null;
        ZoneId zone = ZoneId.systemDefault();
        LocalDate hoy = LocalDate.now(zone);

        switch (rango) {
            case "Esta semana": {
                LocalDate monday = hoy.with(java.time.DayOfWeek.MONDAY);
                return Timestamp.valueOf(LocalDateTime.of(monday, LocalTime.MIDNIGHT));
            }
            case "Este mes": {
                LocalDate first = hoy.withDayOfMonth(1);
                return Timestamp.valueOf(LocalDateTime.of(first, LocalTime.MIDNIGHT));
            }
            case "Este año": {
                LocalDate first = hoy.with(TemporalAdjusters.firstDayOfYear());
                return Timestamp.valueOf(LocalDateTime.of(first, LocalTime.MIDNIGHT));
            }
            case "Todo":
            default:
                return null;
        }
    }

    // ==========================
    // Detalle
    // ==========================
    private void verDetalleSeleccionado() {
        int r = tabla.getSelectedRow();
        if (r == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un renglón para ver el detalle.");
            return;
        }
        int modelRow = tabla.convertRowIndexToModel(r);
        Object id = modelo.getValueAt(modelRow, 3);      // PK ahora está en col 3
        Object cuando = modelo.getValueAt(modelRow, 0);  // fecha

        StringBuilder sb = new StringBuilder();
        sb.append("Numero de Carta Porte: ").append(id).append("\n");
        sb.append("Fecha de Modificación: ").append(cuando).append("\n\n");

        // JSON detalle del último evento
        String detalleJson = "";
        String sqlDet = "SELECT JSON_PRETTY(detalle) FROM " + AUDIT_TABLE +
                        " WHERE Carta_Porte_id = ? ORDER BY modificado_en DESC LIMIT 1";
        try (Connection c = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sqlDet)) {
            ps.setObject(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) detalleJson = nz(rs.getString(1));
            }
        } catch (SQLException ignore) {}

        // Snapshot actual de la fila (si existe)
        String sql = "SELECT * FROM Carta_Porte WHERE Carta_Porte_id = ?";
        try (Connection c = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ResultSetMetaData md = rs.getMetaData();
                    int n = md.getColumnCount();
                    for (int i = 1; i <= n; i++) {
                        String col = md.getColumnLabel(i);
                        Object v = rs.getObject(i);
                        sb.append(col).append(": ").append(v == null ? "" : v.toString()).append("\n");
                    }
                } else {
                    sb.append("(La fila fue eliminada y ya no existe en la Base de datos)");
                }
            }
        } catch (SQLException ex) {
            sb.append("\n[Error al leer detalle: ").append(ex.getMessage()).append("]");
        }

        if (!detalleJson.isEmpty()) {
            sb.append("\n--- Detalle JSON (último evento) ---\n")
              .append(detalleJson).append("\n");
        }

        JTextArea ta = new JTextArea(sb.toString(), 24, 90);
        ta.setWrapStyleWord(true);
        ta.setLineWrap(true);
        ta.setEditable(false);
        ta.setFont(new Font("Consolas", Font.PLAIN, 13));
        JScrollPane jsp = new JScrollPane(ta);
        JOptionPane.showMessageDialog(this, jsp, "Detalle del registro", JOptionPane.INFORMATION_MESSAGE);
    }

    // ==========================
    // Auditoría DDL (opcional)
    // ==========================
    private void asegurarTablaAuditoria() {
        String ddl =
          "CREATE TABLE IF NOT EXISTS " + AUDIT_TABLE + " (" +
          " id BIGINT AUTO_INCREMENT PRIMARY KEY," +
          " Carta_Porte_id INT NOT NULL," +
          " modificado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
          " usuario VARCHAR(100) NULL," +
          " accion ENUM('INSERT','UPDATE','DELETE') NOT NULL," +
          " descripcion VARCHAR(255) NULL," +
          " detalle JSON NULL," +
          " INDEX (Carta_Porte_id)," +
          " INDEX (modificado_en)," +
          " INDEX (accion)" +
          ")";
        try (Connection c = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement()) {
            st.execute(ddl);
        } catch (SQLException ex) {
            System.err.println("[Auditoria] No se pudo asegurar la tabla: " + ex.getMessage());
        }
    }

    // ==========================
    // Estilo
    // ==========================
    private void configurarAnchosColumnas() {
        int[] widths = {
            180, // 0 Modificado en
            90,  // 1 Acción
            200, // 2 Descripción
            120, // 3 ID
            180, // 4 Cliente
            130, // 5 FACTURA
            160, // 6 FECHA_FACTURA
            120, // 7 VALOR
            160, // 8 DESTINO
            150, // 9 OPERADOR
            150, // 10 PLACA_CABEZAL
            160, // 11 PLACA_DEL_FURGON
            110, // 12 PAGADO
            300  // 13 OBSERVACIONES (se expande si sobra ancho)
        };
        TableColumnModel tcm = tabla.getColumnModel();
        for (int i = 0; i < Math.min(widths.length, tcm.getColumnCount()); i++) {
            tcm.getColumn(i).setPreferredWidth(widths[i]);
            tcm.getColumn(i).setMinWidth(70);
        }
    }

    private void aplicarRendererNumericos() {
        DefaultTableCellRenderer rightMoney = new DefaultTableCellRenderer() {
            @Override protected void setValue(Object value) {
                if (value == null) { super.setValue(""); return; }
                try {
                    java.math.BigDecimal bd = (value instanceof java.math.BigDecimal)
                        ? (java.math.BigDecimal) value
                        : new java.math.BigDecimal(value.toString().replace("$","").replace(",","").trim());
                    java.text.NumberFormat nf = java.text.NumberFormat.getCurrencyInstance(new java.util.Locale("es","MX"));
                    super.setValue(nf.format(bd));
                } catch (Exception ex) {
                    super.setValue(value.toString());
                }
            }
        };
        rightMoney.setHorizontalAlignment(SwingConstants.RIGHT);
        // Columna 7 = VALOR
        if (tabla.getColumnModel().getColumnCount() > 7) {
            tabla.getColumnModel().getColumn(7).setCellRenderer(rightMoney);
        }
    }

    private void aplicarZebra() {
        final Color zebraA = Color.WHITE;
        final Color zebraB = new Color(245, 249, 252);

        TableCellRenderer dflt = tabla.getDefaultRenderer(Object.class);
        tabla.setDefaultRenderer(Object.class, (tbl, value, isSelected, hasFocus, row, column) -> {
            Component c = dflt.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
            if (!isSelected) c.setBackground((row % 2 == 0) ? zebraA : zebraB);
            if (c instanceof JComponent) {
                ((JComponent) c).setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6)); // padding
            }
            return c;
        });
    }

    // ==========================
    // util: icono desde recursos
    // ==========================
    private ImageIcon scaledIcon(String resourcePath, int w, int h) {
        try (InputStream is = getClass().getResourceAsStream(resourcePath)) {
            if (is == null) return null;
            BufferedImage img = ImageIO.read(is);
            Image scaled = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (Exception e) { return null; }
    }

    // ==========================
    // MAIN
    // ==========================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Modificaciones_Anteriores().setVisible(true));
    }
}
